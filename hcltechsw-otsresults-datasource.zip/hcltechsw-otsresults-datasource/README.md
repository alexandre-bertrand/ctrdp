# HCL OneTest Server Results Data

[![Build](https://github.com/grafana/grafana-starter-datasource/workflows/CI/badge.svg)](https://github.com/grafana/grafana-starter-datasource/actions?query=workflow%3A%22CI%22)

HCL OneTest Server Results Data is a data source plugin used to access and display results data from HCL OneTest Server.

## Screenshots

![Screenshot](https://help.hcltechsw.com/onetest/hclonetestserver/10.2.2/com.hcl.test.server.testmanager.doc/images/config.jpg)

![Screenshot](https://help.hcltechsw.com/onetest/hclonetestserver/10.2.2/com.hcl.test.server.testmanager.doc/images/explore_query.jpg)

![Screenshot](https://help.hcltechsw.com/onetest/hclonetestserver/10.2.2/com.hcl.test.server.testmanager.doc/images/explore_graph.jpg)

![Screenshot](https://help.hcltechsw.com/onetest/hclonetestserver/10.2.2/com.hcl.test.server.testmanager.doc/images/explore_table.jpg)

## Documentation

Full documentation for the plugin is available on the [website](https://help.hcltechsw.com/onetest/hclonetestserver/10.2.2/com.hcl.test.server.testmanager.doc/topics/c_testmanager_guide.html).
